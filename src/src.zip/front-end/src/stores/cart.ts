import { derived, writable } from 'svelte/store';
import axios from 'axios';


const url = "http://192.168.1.36";

function createCart() {
    const { subscribe, set, update } = writable([]);

    return {
        subscribe,
        update,
        addToCart: (item) => {
            // Récupérer le token de l'utilisateur (ajustez selon votre gestion des tokens)
            const token = window.localStorage.getItem("auth");

            // Appel API pour ajouter un article au panier
            axios.put(`${url}/cart/add/`, { itemId: item.id, quantity: item.quantity }, { withCredentials: true })
                .then(response => {
                    // Mettre à jour le store en ajoutant ou en modifiant l'article
                    update(oldCart => {
                        const itemIndex = oldCart.findIndex(e => e.id === item.id);
                        if (itemIndex === -1) {
                            return [...oldCart, item];
                        } else {
                            oldCart[itemIndex].quantity += item.quantity;
                            return oldCart;
                        }
                    });
                })
                .catch(error => {
                    console.error('Error adding item to cart:', error);
                });
        }
    };
}

export const cart = createCart();

export const totalQuantity = derived(cart, ($cart) =>
	$cart.reduce((acc, curr) => acc + curr.quantity, 0)
);

export const totalPrice = derived(cart, ($cart) =>
	$cart.reduce((acc, curr) => acc + curr.quantity * curr.price, 0)
);
