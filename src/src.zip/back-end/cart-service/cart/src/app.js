const express = require('express')
const log = require('debug')('cart-d')


const app = express.Router()
const utils = require('./utils/utils')

const service = "cart-service"

app.get('/cart/', (req, res) => {
  const token = req.headers.token;

  const operation = "GettingCart"
  utils.sendLog(token, service, "INFO", operation, `Getting cart`, 0)

  return utils.getCart(token)
    .then((result) => {
      utils.sendLog(token, service, "INFO", operation, `Cart succesfully retrieved`, 0)
      res.status(200).json({ status: 'success', result })
    })
    .catch((error) => {
      utils.sendLog(token, service, "ERROR", operation, `Cart not retrived. Info : ${error}`, 0)
      res.status(404).json({ status: 'error', result: String(error)})
    })
});


app.post('/cart/create/', (req, res) => {
  const token = req.headers.token;
  
  const operation = "CartCreation"
  utils.sendLog(token, service, "INFO", operation, `Creating cart`, 0)

  return utils.createCart(token)
    .then((result) => {
      utils.sendLog(token, service, "INFO", operation, `Cart succesfully created`, 0)
      res.status(200).json({ status: 'success', result})
    })
    .catch((error) => {
      utils.sendLog(token, service, "ERROR", operation, `Cart not created. Info : ${error}`, 0)
      res.status(404).json({ status: 'error', result: String(error) })
    })
});

app.delete('/cart/remove/', (req, res) => {
  const token = req.headers.token;
  const itemId = req.body.itemId;

  const operation = "RemoveItem"
  utils.sendLog(token, service, "INFO", operation, `Removing item [${itemId}] from cart`, 0)

  utils.removeFromCart(token, itemId)
    .then(response => {
      utils.sendLog(token, service, "INFO", operation, `Item [${itemId}] succesfully removed from cart`, 0)
      res.status(200).json({ status: 'success', response });
    })
    .catch(error => {
      utils.sendLog(token, service, "ERROR", operation, `Item [${itemId}] with quantity [${quantity}] not removed from the cart. Info : ${error}`, 0)
      res.status(404).json({ status: 'error', message: String(error) });
    });
});

app.put('/cart/add/', (req, res) => {
  const token = req.headers.token;
  const itemId = req.body.itemId; 
  const quantity = req.body.quantity;

  const operation = "AddItem"
  utils.sendLog(token, service, "INFO", operation, `Adding item [${itemId}] with quantity [${quantity}] to cart`, 0)

  utils.addToCart(token, itemId, quantity)
    .then(response => {
      utils.sendLog(token, service, "INFO", operation, `Item [${itemId}] with quantity [${quantity}] succesfully added to cart`, 0)
      res.status(200).json({ status: 'success', response });
    })
    .catch(error => {
      utils.sendLog(token, service, "ERROR", operation, `Item [${itemId}] with quantity [${quantity}] not added to cart. Info : ${error}`, 0)
      res.status(404).json({ status: 'error', message: String(error) });
    });
});

module.exports = app
