const express = require('express')
const log = require('debug')('order-d')


const app = express.Router()
const utils = require('./utils/crud-wp')


app.post('/log/', (req, res) => {
  const token = req.header.token;
  const checkoutData = req.body;
  
  // Traitez les données de checkout ici
  // Par exemple, enregistrer dans la base de données, envoyer un email de confirmation, etc.

  // Répondre au front-end
  res.status(200).json({ message: "Checkout traité avec succès" });
});

module.exports = app
