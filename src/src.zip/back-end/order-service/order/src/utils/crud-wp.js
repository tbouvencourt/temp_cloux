var carts = require('nano')(process.env.DB_URL)
const axios = require('axios');
var user_service = process.env.USER_SERVICE_URL
const log = require('debug')('cart-d')

function getCart(usrToken) {
  return new Promise((resolve, reject) => {
    // Vérifie d'abord le token
    verifyToken(usrToken)
      .then(usrName => {
        // Si le token est valide, récupère le panier de l'utilisateur
        carts.get(usrName, (error, success) => {
          if (error) {
            reject(new Error(`Erreur lors de la récupération du panier de l'utilisateur (${usrName}). Raison : ${error.reason}.`));
          } else {
            resolve(success); // Retourne les données du panier
          }
        });
      })
      .catch(error => {
        // Gère les erreurs liées à la vérification du token
        reject(new Error(`Échec de la vérification du token : ${error}`));
      });
  });
}

function createCart(usrToken) {
  return new Promise((resolve, reject) => {
    verifyToken(usrToken)
      .then(usrName => {
        if (usrName) {

          // Insérer le nouveau panier dans la base de données
          carts.insert({items:[]}, usrName, (error, success) => {
            if (error) {
              // En cas d'erreur, rejeter la promesse
              reject(new Error(`Erreur lors de la création du panier pour ${usrName}: ${error.reason}`));
            } else {
              // Si tout se passe bien, résoudre la promesse avec le résultat
              resolve(success);
            }
          });
        } else {
          reject(new Error(`Invalid token !`));
        }
      })
      .catch(error => {
        // Gère les erreurs liées à la vérification du token
        reject(new Error(`Échec de la vérification du token : ${error}`));
      });
    // Créer un nouveau panier vide
    
  });
}

function removeFromCart(usrToken, itemId) {
  return new Promise((resolve, reject) => {
    verifyToken(usrToken)
      .then(usrName => {
        carts.get(usrName, (error, cart) => {
          if (error) {
            reject(new Error(`Erreur lors de la récupération du panier : ${error.reason}`));
          } else {
            // Retirer l'article du panier
            cart.items = cart.items.filter(item => item.id !== itemId);

            // Mettre à jour le panier dans la base de données
            carts.insert(cart, usrName, (error, success) => {
              if (error) {
                reject(new Error(`Erreur lors de la mise à jour du panier : ${error.reason}`));
              } else {
                resolve(success);
              }
            });
          }
        });
      })
      .catch(error => {
        reject(new Error(`Échec de la vérification du token : ${error}`));
      });
  });
}

function addToCart(usrToken, itemId, quantity) {
  return new Promise((resolve, reject) => {
    verifyToken(usrToken)
      .then(usrName => {
        carts.get(usrName, (error, cart) => {
          if (error) {
            reject(new Error(`Erreur lors de la récupération du panier : ${error.reason}`));
          } else {
            // Vérifie si l'article existe déjà dans le panier
            const itemIndex = cart.items.findIndex(item => item.id === itemId);
            if (itemIndex === -1) {
              // Ajouter le nouvel article
              cart.items.push({ id: itemId, quantity: quantity });
            } else {
              // Mettre à jour la quantité si l'article existe déjà
              cart.items[itemIndex].quantity += quantity;
            }

            // Mettre à jour le panier dans la base de données
            carts.insert(cart, usrName, (error, success) => {
              if (error) {
                reject(new Error(`Erreur lors de la mise à jour du panier : ${error.reason}`));
              } else {
                resolve(success);
              }
            });
          }
        });
      })
      .catch(error => {
        reject(new Error(`Échec de la vérification du token : ${error}`));
      });
  });
}

function verifyToken(usrToken) {
  return new Promise((resolve, reject) => {
    axios.post(`${user_service}/user/validate`, { token: usrToken })
      .then(response => {
        log(response)
        if (response.data && response.data.username) {
          resolve(response.data.username);
        } else {
          resolve(false);
        }
      })
      .catch(error => {
        log(error)
        resolve(false);
      });
  });
}



module.exports = {
  getCart,
  createCart,
  addToCart,
  removeFromCart
}
