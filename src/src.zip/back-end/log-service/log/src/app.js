const express = require('express')
const log = require('debug')('log-d')

const app = express.Router()
const utils = require('./utils/utils')


app.get('/log/:username/:level/:type/:service/:operation/', (req, res) => {
  const token = req.cookies.token;
  const username = req.request.username;
  const level = req.request.level;
  const type = req.request.type;
  const service = req.request.service
  const eventOperation = req.request.operation;  // Event type
  
  const operation = "GetLog"
  utils.sendLog(token, service, "INFO", operation, `Requesting to get logs with parameters : ${username}, ${level}, ${type}, ${service}, ${eventOperation}`, 0)

  return utils.getLog(token, username, level, type, service, eventOperation)
    .then((result) => {
      utils.sendLog(token, service, "INFO", operation, `Logs succesfully gotten`, 0)
      res.status(200).json({ status: 'success', result})
    })
    .catch((error) => {
      utils.sendLog(token, service, "INFO", operation, `Logs not gotten. Details : ${error}`, 0)
      res.status(404).json({ status: 'error', message: String(error) })
    })
});


app.post('/log/create/', (req, res) => {
  const token = req.body.token; // if any
  const timestamp = req.body.timestamp;
  const service = req.body.service; // Service linked to the event
  const type = req.body.type; // ERROR, INFO
  const operation = req.body.operation; // Event type
  const details = req.body.details;  // Event message details
  const responseTime = req.body.responseTime;  // Time response of the request

  return utils.createLog(token, timestamp, type, service, operation, details, responseTime)
    .catch((error) => {
      log(`Log not created. Details : ${error}`)
    })
});



module.exports = app
